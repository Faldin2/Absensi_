﻿Module GlobalDataModule
    Public AbsensiList As New List(Of AbsensiData)
    Public DataMahasiswaList As New List(Of Mahasiswa)

    ' Menyimpan data Absensi ke file
    Public Sub SaveData()
        Dim filePath As String = "AbsensiData.txt"
        Using writer As New IO.StreamWriter(filePath)
            For Each data As AbsensiData In AbsensiList
                writer.WriteLine($"{data.NIM}|{data.Nama}|{data.Kelas}|{data.Tanggal}|{data.Semester}|{data.TahunAkademik}|{data.Izin}|{data.Sakit}|{data.Alpa}")
            Next
        End Using
    End Sub

    ' Memuat data Absensi dari file hanya sekali saat aplikasi pertama kali dijalankan
    Public Sub LoadData()
        ' Jika AbsensiList sudah berisi data, tidak perlu memuat data dari file lagi
        If AbsensiList.Count = 0 Then
            Dim filePath As String = "AbsensiData.txt"
            If IO.File.Exists(filePath) Then
                Using reader As New IO.StreamReader(filePath)
                    While Not reader.EndOfStream
                        Dim line As String = reader.ReadLine()
                        Dim parts() As String = line.Split("|"c)
                        If parts.Length = 9 Then
                            Dim data As New AbsensiData With {
                                .NIM = parts(0),
                                .Nama = parts(1),
                                .Kelas = parts(2),
                                .Tanggal = parts(3),
                                .Semester = parts(4),
                                .TahunAkademik = parts(5),
                                .Izin = parts(6),
                                .Sakit = parts(7),
                                .Alpa = parts(8)
                            }
                            AbsensiList.Add(data)
                        End If
                    End While
                End Using
            End If
        End If
    End Sub
End Module

' Struktur Mahasiswa
Public Class Mahasiswa
    Public Property NIM As String
    Public Property Nama As String
    Public Property Kelas As String
    Public Property Semester As String
    Public Property TahunAkademik As String
End Class
Public Class AbsensiData
    Public Property NIM As String
    Public Property Nama As String
    Public Property Kelas As String
    Public Property Tanggal As String
    Public Property Semester As String
    Public Property TahunAkademik As String
    Public Property Izin As String
    Public Property Sakit As String
    Public Property Alpa As String
End Class