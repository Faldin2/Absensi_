﻿Public Class Form1

    Private TempRowIndex As Integer = -1

    ' Load form pertama kali
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ' Isi ComboBox hanya sekali saat form pertama kali dimuat
        If CmbNIM.Items.Count = 0 Then
            For Each mahasiswa In GlobalDataModule.DataMahasiswaList
                CmbNIM.Items.Add(mahasiswa.NIM)
            Next
        End If
        ' Muat data absensi dari file dan tampilkan di DataGridView
        GlobalDataModule.LoadData()
        RefreshDataGridView()
    End Sub

    ' Refresh DataGridViewAbsensi dengan data absensi dari GlobalDataModule
    Private Sub RefreshDataGridView()
        ' Bersihkan DataGridView terlebih dahulu untuk menghindari data ganda
        DataGridViewAbsensi.Rows.Clear()

        ' Tambahkan data dari AbsensiList ke DataGridView
        For Each data As AbsensiData In GlobalDataModule.AbsensiList
            DataGridViewAbsensi.Rows.Add(data.NIM, data.Nama, data.Kelas, data.Tanggal, data.Semester, data.TahunAkademik, data.Izin, data.Sakit, data.Alpa)
        Next
    End Sub

    ' Simpan data absensi ketika tombol Simpan diklik
    Private Sub Simpan_Click(sender As Object, e As EventArgs) Handles Simpan.Click
        ' Pastikan semua data diinputkan
        If String.IsNullOrWhiteSpace(CmbNIM.Text) OrElse String.IsNullOrWhiteSpace(TxtNama.Text) Then
            MessageBox.Show("Harap lengkapi semua data!")
            Return
        End If

        ' Tambahkan data baru ke daftar
        Dim newData As New AbsensiData With {
        .NIM = CmbNIM.Text,
        .Nama = TxtNama.Text,
        .Kelas = TxtKelas.Text,
        .Tanggal = DateTimePicker1.Text,
        .Semester = TxtSemester.Text,
        .TahunAkademik = TxtTahunAkademik.Text,
        .Izin = TxtIzin.Text,
        .Sakit = TxtSakit.Text,
        .Alpa = TxtAlpa.Text
    }

        ' Menambahkan data baru ke dalam list AbsensiList
        GlobalDataModule.AbsensiList.Add(newData)

        ' Simpan data ke file
        GlobalDataModule.SaveData()

        ' Refresh DataGridView untuk menampilkan data yang baru ditambahkan
        RefreshDataGridView()

        ' Bersihkan input
        ClearInputFields()

        ' Menampilkan pesan berhasil
        MessageBox.Show("Data berhasil disimpan!", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub


    ' Bersihkan input field setelah simpan atau edit
    Private Sub ClearInputFields()
        ' Bersihkan semua input field
        CmbNIM.SelectedIndex = -1 ' Mengatur ComboBox ke keadaan awal
        TxtNama.Clear()
        TxtKelas.Clear()
        DateTimePicker1.Value = DateTime.Now
        TxtSemester.Clear()
        TxtTahunAkademik.Clear()
        TxtIzin.Clear()
        TxtSakit.Clear()
        TxtAlpa.Clear()
    End Sub

    ' Hapus data absensi yang dipilih dari DataGridView
    Private Sub Hapus_Click(sender As Object, e As EventArgs) Handles Hapus.Click
        If DataGridViewAbsensi.SelectedRows.Count > 0 Then
            Dim selectedRowIndex As Integer = DataGridViewAbsensi.SelectedRows(0).Index
            GlobalDataModule.AbsensiList.RemoveAt(selectedRowIndex)

            ' Simpan perubahan ke file
            GlobalDataModule.SaveData()

            ' Refresh DataGridView
            RefreshDataGridView()
            MessageBox.Show("Data mahasiswa berhasil dihapus!", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            MessageBox.Show("Pilih baris yang ingin dihapus!")
        End If
    End Sub

    ' Keluar aplikasi
    Private Sub Keluar_Click(sender As Object, e As EventArgs) Handles Keluar.Click
        Application.Exit()
    End Sub

    ' Klik pada DataGridViewAbsensi untuk memilih data yang akan diedit
    Private Sub DataGridViewAbsensi_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridViewAbsensi.CellContentClick
        If e.RowIndex >= 0 AndAlso e.RowIndex < DataGridViewAbsensi.Rows.Count Then
            Dim selectedRowIndex As Integer = e.RowIndex

            ' Ambil data dari baris yang diklik
            Dim selectedData As AbsensiData = GlobalDataModule.AbsensiList(selectedRowIndex)

            ' Masukkan data ke TextBox dan kontrol input
            CmbNIM.Text = selectedData.NIM
            TxtNama.Text = selectedData.Nama
            TxtKelas.Text = selectedData.Kelas
            DateTimePicker1.Text = selectedData.Tanggal
            TxtSemester.Text = selectedData.Semester
            TxtTahunAkademik.Text = selectedData.TahunAkademik
            TxtIzin.Text = selectedData.Izin
            TxtSakit.Text = selectedData.Sakit
            TxtAlpa.Text = selectedData.Alpa

            ' Simpan indeks baris yang dipilih ke variabel global sementara
            TempRowIndex = selectedRowIndex
        End If
    End Sub

    ' Update data absensi setelah memilih baris untuk diedit
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If TempRowIndex >= 0 AndAlso TempRowIndex < GlobalDataModule.AbsensiList.Count Then
            ' Ambil data dari input field
            Dim updatedData As AbsensiData = GlobalDataModule.AbsensiList(TempRowIndex)
            updatedData.NIM = CmbNIM.Text
            updatedData.Nama = TxtNama.Text
            updatedData.Kelas = TxtKelas.Text
            updatedData.Tanggal = DateTimePicker1.Text
            updatedData.Semester = TxtSemester.Text
            updatedData.TahunAkademik = TxtTahunAkademik.Text
            updatedData.Izin = TxtIzin.Text
            updatedData.Sakit = TxtSakit.Text
            updatedData.Alpa = TxtAlpa.Text

            ' Simpan perubahan ke file
            GlobalDataModule.SaveData()

            ' Refresh DataGridView
            RefreshDataGridView()

            ' Bersihkan input fields
            ClearInputFields()

            ' Reset indeks sementara
            TempRowIndex = -1

            MessageBox.Show("Data berhasil diubah!", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            MessageBox.Show("Tidak ada data yang sedang diedit. Klik dua kali pada baris untuk memilih data!", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    ' Pilih data mahasiswa dari ComboBox untuk ditampilkan di input fields
    Private Sub CmbNIM_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmbNIM.SelectedIndexChanged
        If CmbNIM.SelectedItem IsNot Nothing Then
            Dim selectedNIM As String = CmbNIM.SelectedItem.ToString()
            CmbNIM.Items.Clear()
            ' Cari data mahasiswa berdasarkan NIM
            Dim mahasiswa = GlobalDataModule.DataMahasiswaList.FirstOrDefault(Function(m) m.NIM = selectedNIM)

            ' Jika ditemukan, tampilkan data di TextBox
            If mahasiswa IsNot Nothing Then
                TxtNama.Text = mahasiswa.Nama
                TxtKelas.Text = mahasiswa.Kelas
                TxtSemester.Text = mahasiswa.Semester
                TxtTahunAkademik.Text = mahasiswa.TahunAkademik
            End If
        End If
    End Sub


    ' Kembali ke form Data_Mahasiswa
    Private Sub Button1_Click(sender As Object, e As EventArgs)
        Dim Data_Mahasiswa As New Data_Mahasiswa
        Data_Mahasiswa.Show()
        Close()
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        CmbNIM.SelectedIndex = -1 ' Mengosongkan ComboBox NIM
        TxtNama.Clear() ' Mengosongkan TextBox Nama
        TxtKelas.Clear() ' Mengosongkan TextBox Kelas
        DateTimePicker1.Value = DateTime.Now ' Mengatur DateTimePicker ke tanggal sekarang
        TxtSemester.Clear() ' Mengosongkan TextBox Semester
        TxtTahunAkademik.Clear() ' Mengosongkan TextBox Tahun Akademik
        TxtIzin.Clear() ' Mengosongkan TextBox Izin
        TxtSakit.Clear() ' Mengosongkan TextBox Sakit
        TxtAlpa.Clear() ' Mengosongkan TextBox Alpa

        ' Menyembunyikan atau mengatur nilai default lainnya jika diperlukan
        ' Contoh: Jika Anda menggunakan ComboBox untuk memilih status atau dropdown lainnya
        ' ComboBoxStatus.SelectedIndex = -1
    End Sub
End Class
