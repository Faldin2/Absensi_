﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        Label7 = New Label()
        Label8 = New Label()
        Label9 = New Label()
        TxtNama = New TextBox()
        TxtKelas = New TextBox()
        DateTimePicker1 = New DateTimePicker()
        TxtSemester = New TextBox()
        TxtTahunAkademik = New TextBox()
        TxtIzin = New TextBox()
        TxtSakit = New TextBox()
        TxtAlpa = New TextBox()
        DataGridViewAbsensi = New DataGridView()
        Column1 = New DataGridViewTextBoxColumn()
        Column2 = New DataGridViewTextBoxColumn()
        Column3 = New DataGridViewTextBoxColumn()
        Column4 = New DataGridViewTextBoxColumn()
        Column5 = New DataGridViewTextBoxColumn()
        Column6 = New DataGridViewTextBoxColumn()
        Column7 = New DataGridViewTextBoxColumn()
        Column8 = New DataGridViewTextBoxColumn()
        Column9 = New DataGridViewTextBoxColumn()
        Simpan = New Button()
        Button2 = New Button()
        Hapus = New Button()
        Keluar = New Button()
        Label10 = New Label()
        Panel1 = New Panel()
        CmbNIM = New ComboBox()
        Button1 = New Button()
        CType(DataGridViewAbsensi, ComponentModel.ISupportInitialize).BeginInit()
        Panel1.SuspendLayout()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label1.Location = New Point(57, 176)
        Label1.Name = "Label1"
        Label1.Size = New Size(196, 28)
        Label1.TabIndex = 0
        Label1.Text = "NIM                       :"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label2.Location = New Point(57, 245)
        Label2.Name = "Label2"
        Label2.Size = New Size(199, 28)
        Label2.TabIndex = 3
        Label2.Text = "Nama                     :"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label3.Location = New Point(57, 313)
        Label3.Name = "Label3"
        Label3.Size = New Size(199, 28)
        Label3.TabIndex = 4
        Label3.Text = "Kelas                      :"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label4.Location = New Point(57, 386)
        Label4.Name = "Label4"
        Label4.Size = New Size(199, 28)
        Label4.TabIndex = 5
        Label4.Text = "Tanggal                  :"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label5.Location = New Point(58, 460)
        Label5.Name = "Label5"
        Label5.Size = New Size(200, 28)
        Label5.TabIndex = 6
        Label5.Text = "Semester                :"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label6.Location = New Point(58, 529)
        Label6.Name = "Label6"
        Label6.Size = New Size(198, 28)
        Label6.TabIndex = 7
        Label6.Text = "Tahun Akademik    :"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label7.Location = New Point(58, 607)
        Label7.Name = "Label7"
        Label7.Size = New Size(195, 28)
        Label7.TabIndex = 8
        Label7.Text = " Izin                       :"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label8.Location = New Point(57, 679)
        Label8.Name = "Label8"
        Label8.Size = New Size(196, 28)
        Label8.TabIndex = 9
        Label8.Text = "Sakit                      :"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label9.Location = New Point(57, 746)
        Label9.Name = "Label9"
        Label9.Size = New Size(198, 28)
        Label9.TabIndex = 10
        Label9.Text = "Alpa                       :"
        ' 
        ' TxtNama
        ' 
        TxtNama.Location = New Point(270, 245)
        TxtNama.Name = "TxtNama"
        TxtNama.Size = New Size(325, 31)
        TxtNama.TabIndex = 11
        ' 
        ' TxtKelas
        ' 
        TxtKelas.Location = New Point(270, 313)
        TxtKelas.Name = "TxtKelas"
        TxtKelas.Size = New Size(325, 31)
        TxtKelas.TabIndex = 12
        ' 
        ' DateTimePicker1
        ' 
        DateTimePicker1.Location = New Point(270, 383)
        DateTimePicker1.Name = "DateTimePicker1"
        DateTimePicker1.Size = New Size(325, 31)
        DateTimePicker1.TabIndex = 13
        ' 
        ' TxtSemester
        ' 
        TxtSemester.Location = New Point(270, 457)
        TxtSemester.Name = "TxtSemester"
        TxtSemester.Size = New Size(325, 31)
        TxtSemester.TabIndex = 14
        ' 
        ' TxtTahunAkademik
        ' 
        TxtTahunAkademik.Location = New Point(270, 529)
        TxtTahunAkademik.Name = "TxtTahunAkademik"
        TxtTahunAkademik.Size = New Size(325, 31)
        TxtTahunAkademik.TabIndex = 15
        ' 
        ' TxtIzin
        ' 
        TxtIzin.Location = New Point(270, 607)
        TxtIzin.Name = "TxtIzin"
        TxtIzin.Size = New Size(325, 31)
        TxtIzin.TabIndex = 16
        ' 
        ' TxtSakit
        ' 
        TxtSakit.Location = New Point(270, 679)
        TxtSakit.Name = "TxtSakit"
        TxtSakit.Size = New Size(325, 31)
        TxtSakit.TabIndex = 17
        ' 
        ' TxtAlpa
        ' 
        TxtAlpa.Location = New Point(270, 746)
        TxtAlpa.Name = "TxtAlpa"
        TxtAlpa.Size = New Size(325, 31)
        TxtAlpa.TabIndex = 18
        ' 
        ' DataGridViewAbsensi
        ' 
        DataGridViewAbsensi.AllowUserToAddRows = False
        DataGridViewAbsensi.BackgroundColor = Color.SteelBlue
        DataGridViewAbsensi.BorderStyle = BorderStyle.Fixed3D
        DataGridViewAbsensi.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewAbsensi.Columns.AddRange(New DataGridViewColumn() {Column1, Column2, Column3, Column4, Column5, Column6, Column7, Column8, Column9})
        DataGridViewAbsensi.Location = New Point(647, 176)
        DataGridViewAbsensi.Name = "DataGridViewAbsensi"
        DataGridViewAbsensi.RowHeadersWidth = 62
        DataGridViewAbsensi.Size = New Size(874, 672)
        DataGridViewAbsensi.TabIndex = 19
        ' 
        ' Column1
        ' 
        Column1.HeaderText = "NIM"
        Column1.MinimumWidth = 8
        Column1.Name = "Column1"
        Column1.Width = 150
        ' 
        ' Column2
        ' 
        Column2.HeaderText = "Nama"
        Column2.MinimumWidth = 8
        Column2.Name = "Column2"
        Column2.Width = 150
        ' 
        ' Column3
        ' 
        Column3.HeaderText = "Kelas"
        Column3.MinimumWidth = 8
        Column3.Name = "Column3"
        Column3.Width = 150
        ' 
        ' Column4
        ' 
        Column4.HeaderText = "Tanggal"
        Column4.MinimumWidth = 8
        Column4.Name = "Column4"
        Column4.Width = 150
        ' 
        ' Column5
        ' 
        Column5.HeaderText = "Semester"
        Column5.MinimumWidth = 8
        Column5.Name = "Column5"
        Column5.Width = 150
        ' 
        ' Column6
        ' 
        Column6.HeaderText = "Tahun Akademik"
        Column6.MinimumWidth = 8
        Column6.Name = "Column6"
        Column6.Width = 150
        ' 
        ' Column7
        ' 
        Column7.HeaderText = "Izin"
        Column7.MinimumWidth = 8
        Column7.Name = "Column7"
        Column7.Width = 150
        ' 
        ' Column8
        ' 
        Column8.HeaderText = "Sakit"
        Column8.MinimumWidth = 8
        Column8.Name = "Column8"
        Column8.Width = 150
        ' 
        ' Column9
        ' 
        Column9.HeaderText = "Alpa"
        Column9.MinimumWidth = 8
        Column9.Name = "Column9"
        Column9.Width = 150
        ' 
        ' Simpan
        ' 
        Simpan.Location = New Point(57, 805)
        Simpan.Name = "Simpan"
        Simpan.Size = New Size(124, 43)
        Simpan.TabIndex = 20
        Simpan.Text = "SIMPAN"
        Simpan.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(197, 805)
        Button2.Name = "Button2"
        Button2.Size = New Size(124, 43)
        Button2.TabIndex = 21
        Button2.Text = "UBAH"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Hapus
        ' 
        Hapus.Location = New Point(347, 805)
        Hapus.Name = "Hapus"
        Hapus.Size = New Size(124, 43)
        Hapus.TabIndex = 22
        Hapus.Text = "HAPUS"
        Hapus.UseVisualStyleBackColor = True
        ' 
        ' Keluar
        ' 
        Keluar.Location = New Point(12, 54)
        Keluar.Name = "Keluar"
        Keluar.Size = New Size(124, 43)
        Keluar.TabIndex = 23
        Keluar.Text = "KELUAR"
        Keluar.UseVisualStyleBackColor = True
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.BackColor = Color.Transparent
        Label10.Font = New Font("Segoe UI", 16F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label10.Location = New Point(229, 47)
        Label10.Name = "Label10"
        Label10.Size = New Size(964, 45)
        Label10.TabIndex = 24
        Label10.Text = "ABSENSI MAHASISWA SISTEM INFORMASI ANGAKATAN 2023"
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.MediumTurquoise
        Panel1.Controls.Add(Label10)
        Panel1.Controls.Add(Keluar)
        Panel1.Dock = DockStyle.Top
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(1534, 141)
        Panel1.TabIndex = 25
        ' 
        ' CmbNIM
        ' 
        CmbNIM.FormattingEnabled = True
        CmbNIM.Location = New Point(270, 176)
        CmbNIM.Name = "CmbNIM"
        CmbNIM.Size = New Size(325, 33)
        CmbNIM.TabIndex = 26
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(495, 805)
        Button1.Name = "Button1"
        Button1.Size = New Size(124, 43)
        Button1.TabIndex = 27
        Button1.Text = "CLEAR"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ActiveCaption
        ClientSize = New Size(1534, 875)
        Controls.Add(Button1)
        Controls.Add(CmbNIM)
        Controls.Add(Panel1)
        Controls.Add(Hapus)
        Controls.Add(Button2)
        Controls.Add(Simpan)
        Controls.Add(DataGridViewAbsensi)
        Controls.Add(TxtAlpa)
        Controls.Add(TxtSakit)
        Controls.Add(TxtIzin)
        Controls.Add(TxtTahunAkademik)
        Controls.Add(TxtSemester)
        Controls.Add(DateTimePicker1)
        Controls.Add(TxtKelas)
        Controls.Add(TxtNama)
        Controls.Add(Label9)
        Controls.Add(Label8)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        FormBorderStyle = FormBorderStyle.None
        Name = "Form1"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Form1"
        CType(DataGridViewAbsensi, ComponentModel.ISupportInitialize).EndInit()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents TxtNama As TextBox
    Friend WithEvents TxtKelas As TextBox
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents TxtSemester As TextBox
    Friend WithEvents TxtTahunAkademik As TextBox
    Friend WithEvents TxtIzin As TextBox
    Friend WithEvents TxtSakit As TextBox
    Friend WithEvents TxtAlpa As TextBox
    Friend WithEvents DataGridViewAbsensi As DataGridView
    Friend WithEvents Simpan As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Hapus As Button
    Friend WithEvents Keluar As Button
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents Column7 As DataGridViewTextBoxColumn
    Friend WithEvents Column8 As DataGridViewTextBoxColumn
    Friend WithEvents Column9 As DataGridViewTextBoxColumn
    Friend WithEvents Label10 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents CmbNIM As ComboBox
    Friend WithEvents Button1 As Button

End Class
