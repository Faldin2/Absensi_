﻿Imports System.IO

Public Class Data_Mahasiswa
    Private Sub Simpan_Click(sender As Object, e As EventArgs) Handles Simpan.Click
        If String.IsNullOrEmpty(TxtNIM.Text) OrElse String.IsNullOrEmpty(TxtNama.Text) OrElse
       String.IsNullOrEmpty(TxtKelas.Text) OrElse String.IsNullOrEmpty(TxtSemester.Text) OrElse
       String.IsNullOrEmpty(TxtTahunAkademik.Text) Then
            MessageBox.Show("Semua field harus diisi!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Buat objek Mahasiswa baru
        Dim mahasiswaBaru As New Mahasiswa With {
        .NIM = TxtNIM.Text,
        .Nama = TxtNama.Text,
        .Kelas = TxtKelas.Text,
        .Semester = TxtSemester.Text,
        .TahunAkademik = TxtTahunAkademik.Text
    }

        ' Tambahkan ke list global
        DataMahasiswaList.Add(mahasiswaBaru)

        ' Simpan data ke DataGridView
        DataGridViewDatamahasiswa.Rows.Add(mahasiswaBaru.NIM, mahasiswaBaru.Nama, mahasiswaBaru.Kelas, mahasiswaBaru.Semester, mahasiswaBaru.TahunAkademik)

        ' Simpan data ke file
        SimpanDataKeFile()

        ' Bersihkan input field
        ClearInputFields()

        ' Tampilkan pesan sukses
        MessageBox.Show("Data berhasil disimpan!", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub
    Private Sub ClearInputFields()
        TxtNIM.Clear()
        TxtNama.Clear()
        TxtKelas.Clear()
        TxtSemester.Clear()
        TxtTahunAkademik.Clear()
    End Sub

    Private Sub Data_Mahasiswa_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MuatDataDariFile()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim Form1 As New Form1
        Form1.Show()
        Me.Hide()
    End Sub
    Private Sub SimpanDataKeFile()
        Try
            ' Tentukan lokasi file untuk menyimpan data
            Dim filePath As String = "DataMahasiswa.txt"

            ' Buat objek StreamWriter untuk menulis ke file
            Using writer As New StreamWriter(filePath, False) ' False untuk menimpa file lama
                ' Loop melalui setiap mahasiswa dalam DataMahasiswaList
                For Each mahasiswa As Mahasiswa In DataMahasiswaList
                    ' Tulis data mahasiswa ke dalam file dengan pemisah "|"
                    Dim line As String = $"{mahasiswa.NIM}|{mahasiswa.Nama}|{mahasiswa.Kelas}|{mahasiswa.Semester}|{mahasiswa.TahunAkademik}"
                    writer.WriteLine(line)
                Next
            End Using
        Catch
        End Try
    End Sub
    Private Sub MuatDataDariFile()
        Try
            ' Tentukan lokasi file untuk memuat data
            Dim filePath As String = "DataMahasiswa.txt"

            ' Periksa apakah file ada
            If File.Exists(filePath) Then
                ' Baca semua baris dari file
                Dim lines As String() = File.ReadAllLines(filePath)

                ' Loop setiap baris dan tambahkan ke list
                For Each line In lines
                    Dim data As String() = line.Split("|"c)
                    If data.Length = 5 Then
                        Dim mahasiswa As New Mahasiswa With {
                        .NIM = data(0),
                        .Nama = data(1),
                        .Kelas = data(2),
                        .Semester = data(3),
                        .TahunAkademik = data(4)
                    }
                        DataMahasiswaList.Add(mahasiswa)

                        ' Tambahkan data mahasiswa ke DataGridView
                        DataGridViewDatamahasiswa.Rows.Add(mahasiswa.NIM, mahasiswa.Nama, mahasiswa.Kelas, mahasiswa.Semester, mahasiswa.TahunAkademik)
                    End If
                Next
            Else
                MessageBox.Show("File tidak ditemukan. Data baru akan disimpan.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End If
        Catch ex As Exception
            MessageBox.Show("Terjadi kesalahan saat memuat data dari file: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ' Periksa apakah ada baris yang dipilih di DataGridView
        If DataGridViewDatamahasiswa.SelectedRows.Count > 0 Then
            ' Ambil NIM dari baris yang dipilih
            Dim selectedRow As DataGridViewRow = DataGridViewDatamahasiswa.SelectedRows(0)
            Dim selectedNIM As String = selectedRow.Cells("Column1").Value.ToString()

            ' Cari dan hapus mahasiswa dari DataMahasiswaList
            Dim mahasiswaToRemove As Mahasiswa = DataMahasiswaList.FirstOrDefault(Function(m) m.NIM = selectedNIM)

            If mahasiswaToRemove IsNot Nothing Then
                ' Hapus mahasiswa dari list
                DataMahasiswaList.Remove(mahasiswaToRemove)

                ' Simpan data yang telah diperbarui ke file
                SimpanDataKeFile()

                ' Hapus baris dari DataGridView
                DataGridViewDatamahasiswa.Rows.Remove(selectedRow)

                ' Tampilkan pesan sukses
                MessageBox.Show("Data mahasiswa berhasil dihapus!", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("Mahasiswa tidak ditemukan!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End If
        Else
            MessageBox.Show("Pilih baris yang ingin dihapus terlebih dahulu!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub

    Private Sub TxtNIM_TextChanged(sender As Object, e As EventArgs) Handles TxtNIM.TextChanged

    End Sub
End Class