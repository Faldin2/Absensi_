﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Data_Mahasiswa
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        TxtTahunAkademik = New TextBox()
        TxtSemester = New TextBox()
        TxtKelas = New TextBox()
        TxtNama = New TextBox()
        Label6 = New Label()
        Label5 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        TxtNIM = New TextBox()
        Label1 = New Label()
        DataGridViewDatamahasiswa = New DataGridView()
        Column1 = New DataGridViewTextBoxColumn()
        Column2 = New DataGridViewTextBoxColumn()
        Column3 = New DataGridViewTextBoxColumn()
        Column5 = New DataGridViewTextBoxColumn()
        Column6 = New DataGridViewTextBoxColumn()
        Simpan = New Button()
        Button1 = New Button()
        Button2 = New Button()
        Panel1 = New Panel()
        Label10 = New Label()
        CType(DataGridViewDatamahasiswa, ComponentModel.ISupportInitialize).BeginInit()
        Panel1.SuspendLayout()
        SuspendLayout()
        ' 
        ' TxtTahunAkademik
        ' 
        TxtTahunAkademik.Location = New Point(257, 475)
        TxtTahunAkademik.Name = "TxtTahunAkademik"
        TxtTahunAkademik.Size = New Size(320, 31)
        TxtTahunAkademik.TabIndex = 27
        ' 
        ' TxtSemester
        ' 
        TxtSemester.Location = New Point(257, 403)
        TxtSemester.Name = "TxtSemester"
        TxtSemester.Size = New Size(320, 31)
        TxtSemester.TabIndex = 26
        ' 
        ' TxtKelas
        ' 
        TxtKelas.Location = New Point(257, 340)
        TxtKelas.Name = "TxtKelas"
        TxtKelas.Size = New Size(325, 31)
        TxtKelas.TabIndex = 24
        ' 
        ' TxtNama
        ' 
        TxtNama.Location = New Point(257, 272)
        TxtNama.Name = "TxtNama"
        TxtNama.Size = New Size(325, 31)
        TxtNama.TabIndex = 23
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label6.Location = New Point(40, 475)
        Label6.Name = "Label6"
        Label6.Size = New Size(198, 28)
        Label6.TabIndex = 22
        Label6.Text = "Tahun Akademik    :"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label5.Location = New Point(40, 406)
        Label5.Name = "Label5"
        Label5.Size = New Size(200, 28)
        Label5.TabIndex = 21
        Label5.Text = "Semester                :"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label3.Location = New Point(44, 340)
        Label3.Name = "Label3"
        Label3.Size = New Size(199, 28)
        Label3.TabIndex = 19
        Label3.Text = "Kelas                      :"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label2.Location = New Point(44, 272)
        Label2.Name = "Label2"
        Label2.Size = New Size(199, 28)
        Label2.TabIndex = 18
        Label2.Text = "Nama                     :"
        ' 
        ' TxtNIM
        ' 
        TxtNIM.Location = New Point(257, 203)
        TxtNIM.Name = "TxtNIM"
        TxtNIM.Size = New Size(325, 31)
        TxtNIM.TabIndex = 17
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        Label1.Location = New Point(44, 203)
        Label1.Name = "Label1"
        Label1.Size = New Size(196, 28)
        Label1.TabIndex = 16
        Label1.Text = "NIM                       :"
        ' 
        ' DataGridViewDatamahasiswa
        ' 
        DataGridViewDatamahasiswa.AllowUserToAddRows = False
        DataGridViewDatamahasiswa.BackgroundColor = Color.SteelBlue
        DataGridViewDatamahasiswa.BorderStyle = BorderStyle.Fixed3D
        DataGridViewDatamahasiswa.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewDatamahasiswa.Columns.AddRange(New DataGridViewColumn() {Column1, Column2, Column3, Column5, Column6})
        DataGridViewDatamahasiswa.Location = New Point(607, 199)
        DataGridViewDatamahasiswa.Name = "DataGridViewDatamahasiswa"
        DataGridViewDatamahasiswa.RowHeadersWidth = 62
        DataGridViewDatamahasiswa.Size = New Size(874, 472)
        DataGridViewDatamahasiswa.TabIndex = 28
        ' 
        ' Column1
        ' 
        Column1.HeaderText = "NIM"
        Column1.MinimumWidth = 8
        Column1.Name = "Column1"
        Column1.Width = 150
        ' 
        ' Column2
        ' 
        Column2.HeaderText = "Nama"
        Column2.MinimumWidth = 8
        Column2.Name = "Column2"
        Column2.Width = 150
        ' 
        ' Column3
        ' 
        Column3.HeaderText = "Kelas"
        Column3.MinimumWidth = 8
        Column3.Name = "Column3"
        Column3.Width = 150
        ' 
        ' Column5
        ' 
        Column5.HeaderText = "Semester"
        Column5.MinimumWidth = 8
        Column5.Name = "Column5"
        Column5.Width = 150
        ' 
        ' Column6
        ' 
        Column6.HeaderText = "Tahun Akademik"
        Column6.MinimumWidth = 8
        Column6.Name = "Column6"
        Column6.Width = 150
        ' 
        ' Simpan
        ' 
        Simpan.Location = New Point(91, 563)
        Simpan.Name = "Simpan"
        Simpan.Size = New Size(124, 43)
        Simpan.TabIndex = 29
        Simpan.Text = "SIMPAN"
        Simpan.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(401, 563)
        Button1.Name = "Button1"
        Button1.Size = New Size(150, 43)
        Button1.TabIndex = 30
        Button1.Text = "DATA ABSENSI"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(241, 563)
        Button2.Name = "Button2"
        Button2.Size = New Size(124, 43)
        Button2.TabIndex = 31
        Button2.Text = "HAPUS"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.MediumTurquoise
        Panel1.Controls.Add(Label10)
        Panel1.Dock = DockStyle.Top
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(1493, 146)
        Panel1.TabIndex = 32
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.BackColor = Color.Transparent
        Label10.Font = New Font("Segoe UI", 16F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label10.Location = New Point(516, 49)
        Label10.Name = "Label10"
        Label10.Size = New Size(422, 45)
        Label10.TabIndex = 24
        Label10.Text = "INPUT DATA MAHASISWA"
        ' 
        ' Data_Mahasiswa
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ActiveCaption
        ClientSize = New Size(1493, 774)
        Controls.Add(Panel1)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(Simpan)
        Controls.Add(DataGridViewDatamahasiswa)
        Controls.Add(TxtTahunAkademik)
        Controls.Add(TxtSemester)
        Controls.Add(TxtKelas)
        Controls.Add(TxtNama)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(TxtNIM)
        Controls.Add(Label1)
        Name = "Data_Mahasiswa"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Data_Mahasiswa"
        CType(DataGridViewDatamahasiswa, ComponentModel.ISupportInitialize).EndInit()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents TxtTahunAkademik As TextBox
    Friend WithEvents TxtSemester As TextBox
    Friend WithEvents TxtKelas As TextBox
    Friend WithEvents TxtNama As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TxtNIM As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents DataGridViewDatamahasiswa As DataGridView
    Friend WithEvents Simpan As Button
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label10 As Label
End Class
